<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="css/bootstrap.css">
		<title>Consumindo um webservice</title>
	</head>
	<body>
		<div class="container mt-2">
		<h1>Uninove</h1>
		<h6>Cadastro de Clientes</h6>
		<hr/>
		<p align="right"><a href="cadastro.php" class="btn btn-success">Novo Cliente</a></p>
		<?php
			// URL do Webservice Rest
			$webservice = "http://localhost:8080/RestFul/cliente/listarTodos";
			
			// Recuperar o objeto JSON
			$clientes = file_get_contents($webservice);
			
			// Transformar o JSON em objeto PHP
			$jsonObj = json_decode($clientes);
		
			// Criar um array de objetos cliente
			$clientes = $jsonObj->cliente;
			
			echo "<table class='table table-hover'>";
				echo "<tr class='font-weight-bold bg-info text-white'>";
					echo "<td>Código</td>";
					echo "<td>Nome</td>";
					echo "<td>CPF</td>";
					echo "<td>Endereço</td>";
					echo "<td></td>";
				echo "</tr>";
			
			foreach ( $clientes as $c){
				echo "<tr>";
					echo "<td align='center'><a href='detalhes.php?id=$c->id'>" . $c->id . "</a></td>";
					echo "<td>" . $c->nome . "</td>";
					echo "<td>" . $c->cpf . "</td>";
					echo "<td>" . $c->endereco . "</td>";
					echo "<td align='center'><a href='confirma.php?id=$c->id'><img src='imagens/lixo16.png'></a></td>";
				echo "</tr>";
			}
			
			echo "</table>";
			
		?>
		</div>
	</body>
</html>









