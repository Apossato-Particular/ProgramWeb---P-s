<html>
	<head>
		<link rel="stylesheet" href="css/bootstrap.css">
		<title>Cadastro</title>
	</head>
	
	<body>
		<div class="container mt-2">
			<h1>Uninove</h1>
			<h6>Cadastro de Clientes</h6>
			<hr/>
			<form action="gravar.php">
				<div class="card m-auto" style="width:600px;">
					<div class="card-header bg-info text-white"><h4>Novo Cliente</h4></div>
					<div class="card-body">
						<input type="text" name="txt-op" value="novo" hidden>
						<div class="row mb-2">
							<div class="col-md-2"><label>Nome:</label></div>
							<div class="col-md-10"><input type="text" name="txt-nome" class="form-control"></div>
						</div>
						<div class="row mb-2">
							<div class="col-md-2"><label>CPF:</label></div>
							<div class="col-md-10"><input type="text" name="txt-cpf" class="form-control"></div>
						</div>
						<div class="row mb-2">
							<div class="col-md-2"><label>Endereço:</label></div>
							<div class="col-md-10"><input type="text" name="txt-endereco" class="form-control"></div>
						</div>
					</div>
					<div class="card-footer">
						<input type="submit" class="btn btn-success" value="Gravar Cliente">
						<a href="index.php" class="btn btn-warning text-white">Cancelar</a>
					</div>
				</div>
			</form>
		</div>
	</body>
	
	
</html>