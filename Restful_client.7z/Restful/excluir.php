			<!DOCTYPE html>
			<html>
				<head>
					<link rel="stylesheet" href="css/bootstrap.css">
					<title>Consumindo um webservice</title>
				</head>
				<body>
					<div class="container mt-2">
					<h1>Uninove</h1>
					<h6>Exclusão de Clientes</h6>
					<hr>

						<?php
								$id = $_GET['id'];
								
								// *** ENDEREÇO DO RECURSO WEBSERVICE
								$url = "http://localhost:8080/RestFul/cliente/excluirCliente/$id/";
								
								// *** ENVIO DE UM REQUEST AO RECURSO
								$cliente = curl_init($url);
								
								curl_setopt($cliente, CURLOPT_POST, 1);
								curl_setopt($cliente, CURLOPT_RETURNTRANSFER, 1);
																
								// *** OBTER A RESPOSTA DO RECURSO
								$response = curl_exec($cliente);
																
								if ($response == true) {
											echo '<h6>Exclusão executada com sucesso</h6>';
											echo '<h4>Registro excluído: '. $id . '</h4>';
								} else {
										echo '<h6>Exclusão falhou</h6>';
											
								}
								
								//header('location: http://localhost/RestFul/index.php');
						?>
					<hr/>
					<p align="right"><a href="index.php" class="btn btn-success">Início</a></p>
				</body>
			</html>