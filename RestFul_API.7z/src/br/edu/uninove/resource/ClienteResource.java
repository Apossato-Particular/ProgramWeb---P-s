package br.edu.uninove.resource;

import java.util.ArrayList;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import br.edu.uninove.controller.ClienteController;
import br.edu.uninove.model.Cliente;

@Path("/cliente")
public class ClienteResource {

	@GET
	@Path("/listarTodos")
	//@Produces("application/json")
	@Produces(MediaType.APPLICATION_JSON)
	public ArrayList<Cliente> listarTodos(){
		return new ClienteController().listarTodos();
	}
	
	@GET
	//@Produces("application/json")
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/listarCliente/{id}/")
	public Cliente listarCliente(@PathParam("id") int id) {
		return new ClienteController().listarCliente(id);
	}
	
	@POST
	//@Produces("application/json")
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/gravar")
	public Response gravar(Cliente cliente){
		System.out.println(cliente.toString());
		System.out.println(cliente.getId());
		System.out.println(cliente.getNome());
		System.out.println(cliente.getCpf());
		System.out.println(cliente.getEndereco());
		
		new ClienteController().gravar(cliente);
		
		return Response.status(Response.Status.OK).build();
	}
	
	@POST
	//@Produces("application/json")
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/atualizar")
	public Response atualizar(Cliente cliente) {
		new ClienteController().atualizar(cliente);
		return Response.status(Response.Status.OK).build();
	}
	
	@POST
	//@Produces("application/json")
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/excluirCliente/{id}/")
	public boolean excluir(@PathParam("id") int id){
		
		return new ClienteController().excluir(id);
		
	}
}
