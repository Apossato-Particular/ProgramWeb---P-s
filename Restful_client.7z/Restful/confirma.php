<!DOCTYPE html>
<?php
		$id = $_GET['id'];
		
		// *** ENDEREÇO DO RECURSO WEBSERVICE
		$url = "http://localhost:8080/RestFul/cliente/listarCliente/$id/";
		
		// *** ENVIO DE UM REQUEST AO RECURSO
		$cliente = curl_init($url);
		curl_setopt($cliente, CURLOPT_RETURNTRANSFER, 1);
		
		// *** OBTER A RESPOSTA DO RECURSO
		$response = curl_exec($cliente);
		
		// *** DECODE - TRANSFORMAR EM UM OBJETO PHP
		$resultado = json_decode($response);
?>
<html>
	<head>
		<link rel="stylesheet" href="css/bootstrap.css">
		<title>Consumindo um webservice</title>
	</head>
	<body>
		<div class="container mt-2">
		<h1>Uninove</h1>
		<h6>Exclusão de Clientes - Confirma Exclusão?</h6>
<?php
	$id = $_GET['id'];
	echo "<h5>Registro a ser excluído: " . $id . "</h5>";
	echo "<table class='table table-hover'>";
				echo "<tr class='font-weight-bold bg-info text-white'>";
					echo "<td>Código</td>";
					echo "<td>Nome</td>";
					echo "<td>CPF</td>";
					echo "<td>Endereço</td>";
					echo "<td></td>";
				echo "</tr>";
				echo "<tr>";
					echo "<td align='center'>" . $resultado->id . "</td>";
					echo "<td>" . $resultado->nome . "</td>";
					echo "<td>" . $resultado->cpf . "</td>";
					echo "<td>" . $resultado->endereco . "</td>";
				echo "</tr>";
	echo "<div class='card-footer'>";
	echo "<p align='right'><a href='excluir.php?id=$id' class='btn btn-success'>Excluir</a><a href='index.php' class='btn btn-warning text-white'>Cancelar</a></p>";
	echo "</div>";
?>
	</body>
</html>